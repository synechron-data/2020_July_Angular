// -------------------------------------------------------------- Default / Auto Bootstrap
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { RouterModule } from "@angular/router";

import { RootComponent } from "./components/root/root.component";
import { BSNavigationComponent } from "./components/bs-nav/bs-nav.component";
import { routes } from "./app.routes";
import { HomeComponent } from "./components/home/home.component";
import { AboutComponent } from "./components/about/about.component";
import { APP_BASE_HREF } from "@angular/common";
import { NotFoundComponent } from "./components/not-found/not-found.component";
import { AuthorsModule } from "./authors-module/authors.module";
import { ProductsComponent } from "./components/products/products.component";
import { ProductDetailsComponent } from "./components/products/pd.component";
import { ProductNotSelectedComponent } from "./components/products/ns.component";
import { AdminComponent } from "./components/admin/admin.component";
import { AuthGuardService } from "./services/auth-guard.service";
import { AuthenticatorService } from "./services/authenticator.service";
import { LoginComponent } from "./components/login/login.component";
import { TokenInterceptorService } from "./services/token-interceptor.service";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule,
        RouterModule.forRoot(routes), AuthorsModule],
    declarations: [RootComponent, BSNavigationComponent, NotFoundComponent, HomeComponent, AboutComponent,
        ProductsComponent, ProductDetailsComponent, ProductNotSelectedComponent,
        AdminComponent, LoginComponent],
    bootstrap: [RootComponent],
    providers: [
        AuthenticatorService,
        AuthGuardService,
        {
            provide: APP_BASE_HREF,
            useValue: '/'
        },
        {
            provide: HTTP_INTERCEPTORS,
            multi: true,
            useClass: TokenInterceptorService
        }
    ]
})
export class AppModule {

}