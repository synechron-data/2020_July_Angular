import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'about.component.html'
})

export class AboutComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}