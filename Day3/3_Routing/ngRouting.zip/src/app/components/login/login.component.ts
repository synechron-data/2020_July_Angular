import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthenticatorService } from '../../services/authenticator.service';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'selector-name',
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading: boolean;
    submitted: boolean;
    returnUrl: string;

    constructor(private _formBuilder: FormBuilder,
        private _aService: AuthenticatorService,
        private _route: ActivatedRoute,
        private _router: Router) { }

    ngOnInit() {
        this.loading = false;
        this.submitted = false;

        this.loginForm = this._formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });

        this.returnUrl = this._route.snapshot.queryParams['returnUrl'] || '/admin';
    }

    get f() { return this.loginForm.controls; }

    onSubmit(e: Event) {
        this.submitted = true;

        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }

        this.loading = true;

        this._aService.login(this.f.username.value, this.f.password.value).pipe(first()).subscribe(
            data => {
                this._router.navigate([this.returnUrl])
            }, error => {
                console.log(error);
                this.loading = false;
            }
        )
    }
}