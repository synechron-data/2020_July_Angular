import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../services/users.service';
import { Subscription } from 'rxjs';

@Component({
    templateUrl: 'admin.component.html',
    providers: [UsersService]
})

export class AdminComponent implements OnInit {
    users: Array<any>;
    message: string;
    gu_sub: Subscription;

    constructor(private _uService: UsersService) { }

    ngOnInit() {
        this.gu_sub = this._uService.getAllUsers().subscribe(resData => {
            this.users = resData.users;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        })
    }

    ngOnDestroy(): void {
        this.gu_sub.unsubscribe();
    }
}