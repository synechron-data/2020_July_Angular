import { Injectable } from '@angular/core';
import { AuthenticatorService } from './authenticator.service';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class TokenInterceptorService implements HttpInterceptor {
    constructor(private _aService: AuthenticatorService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (new RegExp('api/users').test(req.url)) {
            const authReq = req.clone({
                setHeaders: {
                    'x-access-token': this._aService.getToken()
                }
            });

            return next.handle(authReq);
        } else {
            return next.handle(req);
        }
    }
}