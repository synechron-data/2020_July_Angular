import { Component, OnInit, OnDestroy } from '@angular/core';
import { Author } from '../models/app.author';
import { AuthorService } from '../services/author.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'author-quote',
    styleUrls: ['./author-quote.component.css'],
    templateUrl: 'author-quote.component.html'
})

export class AuthorQuoteComponent implements OnInit, OnDestroy {
    selectedAuthor: Author;
    sac_sub: Subscription;

    constructor(private _aService: AuthorService) { }
    
    ngOnInit() {
        this.sac_sub = this._aService.SelectedAuthorChanged.subscribe(() => {
            this.selectedAuthor = this._aService.SelectedAuthor;
        });
    }

    ngOnDestroy(): void {
        this.sac_sub.unsubscribe();
    }
    // getQuote() {
    //     this.selectedAuthor = this._aService.SelectedAuthor;
    // }
}