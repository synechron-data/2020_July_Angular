// -------------------------------------------------------------- Default / Auto Bootstrap
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { RootComponent } from "./root.component";
import { PostService } from "./services/post.service";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule],
    declarations: [RootComponent],
    bootstrap: [RootComponent],
    // providers: [PostService]
})
export class AppModule {

}