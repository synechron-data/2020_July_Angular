// -------------------------------------------------------------- Default / Auto Bootstrap
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

import { RootComponent } from "./root.component";
import { AssignOneComponent } from "./assign-one/assign-one.component";
import { AssignTwoComponent } from "./assign-two/assign-two.component";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, AssignOneComponent, AssignTwoComponent],
    bootstrap: [RootComponent]
})
export class AppModule {

}