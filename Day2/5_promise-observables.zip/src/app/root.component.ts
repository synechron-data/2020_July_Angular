import { Component } from '@angular/core';
import { Observable, Observer, Subject } from 'rxjs';

@Component({
    selector: 'root',
    templateUrl: './root.component.html'
})
export class RootComponent {
    // observable: Observable<number>;
    // subject: Subject<number>;

    constructor() {
        // this.subject = new Subject<number>();

        // setInterval(() => {
        //     this.subject.next(Math.random());
        // }, 2000);

        // this.subject.subscribe(data => {
        //     console.log("Subcriber 1, Output - ", data);
        // });

        // this.subject.subscribe(data => {
        //     console.log("Subcriber 2, Output - ", data);
        // });

        // this.observable = this.getObservable();
        // // console.log(this.observable);

        // this.observable.subscribe(data => {
        //     console.log("Subcriber 1, Output - ", data);
        // });

        // this.observable.subscribe(data => {
        //     console.log("Subcriber 2, Output - ", data);
        // });

        // this.getPromise().then(data => {
        //     console.log("Promise Output - ", data);
        // }, err => {
        //     console.error(err);
        // });
    }

    getObservable(): Observable<number> {
        return Observable.create((ob: Observer<number>) => {
            setInterval(function () {
                ob.next(Math.random());
            }, 2000)
        })
    }

    getPromise(): Promise<number> {
        return new Promise((resolve, reject) => {
            setInterval(function () {
                resolve(Math.random());
            }, 2000)
        })
    }
}
