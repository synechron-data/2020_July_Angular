// -------------------------------------------------------------- Default / Auto Bootstrap
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

import { RootComponent } from "./root.component";
import { AsyncPromiseComponent } from "./async-promise.component";
import { AsyncObComponent } from "./async-ob.component";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, AsyncPromiseComponent, AsyncObComponent],
    bootstrap: [RootComponent]
})
export class AppModule {

}