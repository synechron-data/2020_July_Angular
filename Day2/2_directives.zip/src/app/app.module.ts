// -------------------------------------------------------------- Default / Auto Bootstrap
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

import { RootComponent } from "./root.component";
import { AssignOneComponent } from "./assign-one/assign-one.component";
import { AssignTwoComponent } from "./assign-two/assign-two.component";
import { ListComponent } from "./list/list.component";
import { ChangeContentDirective } from "./directives/change-content.directive";
import { HighlightDirective } from "./directives/highight.directive";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, ListComponent, AssignOneComponent, AssignTwoComponent,
        ChangeContentDirective, HighlightDirective],
    bootstrap: [RootComponent]
})
export class AppModule {

}