import { Component } from '@angular/core';

@Component({
    selector: 'root',
    templateUrl: './root.component.html'
})
export class RootComponent {
    myStyles = {
        'background-color': 'green',
        'font-size': '20px',
        'color': 'white'
    };

    name: string;

    constructor() {
        // this.name = "Synechron";
    }
}
