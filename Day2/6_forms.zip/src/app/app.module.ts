// -------------------------------------------------------------- Default / Auto Bootstrap
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { RootComponent } from "./root.component";
import { TemplatedFormComponent } from "./templated-form/templated-form.component";
import { ReactiveFormComponent } from "./reactive-form/reactive-form.component";
import { ValidationFormComponent } from "./validation-form/validation-form.component";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule],
    declarations: [RootComponent, TemplatedFormComponent, ReactiveFormComponent, ValidationFormComponent],
    bootstrap: [RootComponent]
})
export class AppModule {

}