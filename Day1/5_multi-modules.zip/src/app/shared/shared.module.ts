import { NgModule } from '@angular/core';

import { SharedComponent } from './shared.component';

@NgModule({
    exports: [SharedComponent],
    declarations: [SharedComponent]
})
export class SharedModule { }
