import { Component } from '@angular/core';

@Component({
    selector: 'c-one',
    template: `
        <h1 class="text-success">Hello from Component One - Module One!</h1>
        <s-com></s-com>
    `
})

export class COneComponent { }